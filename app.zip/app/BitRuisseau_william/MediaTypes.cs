﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitRuisseau_william
{
    public enum MediaTypes
    {
        MP3,
        MP4,
        MOV,
        GIF,
        PNG,
        JPEG,
        JPG,
        WAV
    }

}
